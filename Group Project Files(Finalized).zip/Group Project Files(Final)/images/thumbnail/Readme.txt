reason to make this,
if u gonna use high quality image for thumbnail,
it bad for proformance and users cuz it gonna use lot of data for loading.

use this tools to do that
https://www.img2go.com/compress-image
https://compressimage.toolur.com/